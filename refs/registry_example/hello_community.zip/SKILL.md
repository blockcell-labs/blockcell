# Hello Community Skill

This is a sample skill installed from the community registry.

## Usage

User says: "Hello community" or "Test community skill"

## Process

1. The agent acknowledges the community connection.
2. It prints a welcome message.
